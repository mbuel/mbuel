'use strict';
let startGame = new DiceGame();