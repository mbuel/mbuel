'use strict';



const control = new Game();

